function [performance_kpca]=activecombsample(Lset,Uset, beta, options, repeatnum)
%
% combine most uncertain with mutual information weight
% can address multiclass problem, but only for non-batch mode active learning
%
% input:
% Lset: lt x (d+1), labeled set, the last column is the label column
% Uset: ut x (d+1), unlabeled set, the last column is the label column
% Tset: tt x (d+1), test set, the last column is the label column
% beta: (0,1)  the trade off between the uncertainty term and the mutual information term
% options: parameter used for produce kernel matrix
% repeatnum: how many active selections to conduct
%
% subsampling: method to select a subset as candidate
% subsampling.method
%       0: use all
%	1: top most uncertain ones
%	2: clustering
%	3: random selection
% subsampling.num
%	number of candidates
%
% Xin Li
%
% lambda = 0.1;
[ut, d] = size(Uset);               

totalnum = ut;

d = d-1; % num. of features
[lt,lt2] = size(Lset);                 

% classes = unique(Tset(:,d+1));     
% classnum = length(classes);         
classnum = 2;
uK = getkernel(Uset(:,1:d), Uset(:,1:d),options); 

ulist = 1:ut;
U = uK;
%invU = inv(U+1e-8*eye(ut));
invU = pinv(U);              

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for iter = 1:repeatnum
        cand_ids = 1:ut;   
%     if indicator>0
        %compute measure
        labelsetLset = Lset(:,1:lt2-1);
        trainlabelLset = Lset(:,lt2);
        
        Factor =glmfit(labelsetLset, trainlabelLset,'binomial', 'link', 'logit');
        entropyvec = getentropy(Uset(cand_ids,:),Factor,classnum);

%         if length(beta) == 1 %single beta
            if beta~=1.0
                mutualinfo =real(getmutualinfo(cand_ids, U, invU));
                measures = (entropyvec.^beta).*(mutualinfo.^(1-beta));
            else
                measures = entropyvec;
            end
            
            [~,id] = max(measures);
            id = cand_ids(id);
            
            %%%%get the label and move to labeled set, and post process
            ut = ut - 1;
            lt = lt + 1;
            Lset(lt,:) = Uset(id,:);
            Uset(id,:) = [];
            ulist(id) = [];
  
            invU = calInvSubmat(U,invU,id);
            U = uK(ulist, ulist);
            %invU = inv(U+1e-8*eye(ut)); 
            %%% evaluate%%%%%%%%%%%%%%%
            
            if iter == ceil(0.05 * totalnum)
                
                labelset0 = Lset(:,1:size(Lset,2)-1);
                labelsetlabel = Lset(:,size(Lset,2));
                testset0 = Uset(:,1:size(Uset,2)-1);
                testsetlabel = Uset(:,size(Uset,2));
         
                %KPCA
                [test_kpca,train_kpca] = kpcaFordata(testset0,labelset0,95,10);
                labelset_kpca = [train_kpca labelsetlabel];
                testset_kpca = [test_kpca testsetlabel];                
                [F_measure_005_kpca, g_mean_005_kpca, Bal_005_kpca] = measure_LR(labelset_kpca,testset_kpca);
            end
            
            if iter == ceil(0.10 * totalnum)
                
                labelset0 = Lset(:,1:size(Lset,2)-1);
                labelsetlabel = Lset(:,size(Lset,2));
                testset0 = Uset(:,1:size(Uset,2)-1);
                testsetlabel = Uset(:,size(Uset,2));
  
                %KPCA
                [test_kpca,train_kpca] = kpcaFordata(testset0,labelset0,95,10);
                labelset_kpca = [train_kpca labelsetlabel];
                testset_kpca = [test_kpca testsetlabel];                
                [F_measure_010_kpca, g_mean_010_kpca, Bal_010_kpca] = measure_LR(labelset_kpca,testset_kpca);
            end
            
            if iter == ceil(0.15 * totalnum)
                
                labelset0 = Lset(:,1:size(Lset,2)-1);
                labelsetlabel = Lset(:,size(Lset,2));
                testset0 = Uset(:,1:size(Uset,2)-1);
                testsetlabel = Uset(:,size(Uset,2));
                
                %KPCA
                [test_kpca,train_kpca] = kpcaFordata(testset0,labelset0,95,10);
                labelset_kpca = [train_kpca labelsetlabel];
                testset_kpca = [test_kpca testsetlabel];                
                [F_measure_015_kpca, g_mean_015_kpca, Bal_015_kpca] = measure_LR(labelset_kpca,testset_kpca);
            end
            
            if iter == ceil(0.20 * totalnum)
                
                labelset0 = Lset(:,1:size(Lset,2)-1);
                labelsetlabel = Lset(:,size(Lset,2));
                testset0 = Uset(:,1:size(Uset,2)-1);
                testsetlabel = Uset(:,size(Uset,2));

                %KPCA
                [test_kpca,train_kpca] = kpcaFordata(testset0,labelset0,95,10);
                labelset_kpca = [train_kpca labelsetlabel];
                testset_kpca = [test_kpca testsetlabel];                
                [F_measure_020_kpca, g_mean_020_kpca, Bal_020_kpca] = measure_LR(labelset_kpca,testset_kpca);
            end
            
            clear labelset0;
            clear testset0;

            clear labelset;
            clear testset;

            clear labelsetlabel;
            clear testsetlabel;
            
            clear labelset_pca��
            clear testset_pca;
            
            clear labelset_kpca;
            clear testset_kpca;
%     end
end

performance_kpca = [
F_measure_005_kpca, g_mean_005_kpca, Bal_005_kpca
F_measure_010_kpca, g_mean_010_kpca, Bal_010_kpca
F_measure_015_kpca, g_mean_015_kpca, Bal_015_kpca
F_measure_020_kpca, g_mean_020_kpca, Bal_020_kpca];