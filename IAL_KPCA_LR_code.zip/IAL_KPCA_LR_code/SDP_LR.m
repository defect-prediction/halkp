function [F_measure, g_mean, Bal]=SDP_LR(traindata,testdata,trainlabel,testlabel)

Factor =glmfit(traindata,trainlabel,'binomial', 'link', 'logit');
logitFit = glmval(Factor,testdata,'logit'); 

predictlabel = ones(size(testdata,1),1);
for i = 1:size(testdata,1)
    if logitFit(i) <= 0.5
        predictlabel(i) = 0;
    end
end

predictlabel = predictlabel';
testlabel = testlabel';

TN = 0;
FP = 0;
FN = 0;
TP = 0;
for i = 1:size(testlabel,2)
    if (testlabel(i)== 0 && predictlabel(i) == 0)
	    TN = TN + 1;
	elseif (testlabel(i) == 0 && predictlabel(i) == 1)
        FP = FP + 1;
	elseif (testlabel(i) == 1 && predictlabel(i) == 0)
        FN = FN + 1;
    else
        TP = TP + 1;
    end
end

Recall = TP / (TP + FN);
Pd = Recall;
Precision = TP / (TP + FP);
False_Positive = FP / (FP + TN);
Pf = False_Positive;
F_measure = 2 * Precision * Recall / (Precision + Recall);
g_mean = sqrt((TN / (TN + FP)) * (TP / (TP + FN)));
Bal = 1- sqrt((0-Pf)^2+(1-Pd)^2)/sqrt(2);