function [F_measure, g_mean, Bal] = measure_LR(Lset,Uset)

            lt2 = size(Lset,2);
 
            traindataLset = Lset(:,1:lt2-1);
            trainlabelLset = Lset(:,lt2);
  
            testdataUset = Uset(:,1:lt2-1);
            testlabelUset = Uset(:,lt2);
 
            [F_measure, g_mean, Bal] = SDP_LR(traindataLset,testdataUset,trainlabelLset,testlabelUset);