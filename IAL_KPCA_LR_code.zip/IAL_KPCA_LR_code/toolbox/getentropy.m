function entropyvec=getentropy(data,nb,classnum)
%
% compute entropies for the instances 
%
% Y. Guo
% Jan. 8, 2006
%
% data: t*(d+1), the last column is the label column

[t,d]=size(data);

x=[data(:,1:d-1),ones(t,1)]';

%y=data(:,d)';
%v=unique(y);
%classnum=size(v,2);

if classnum<=2
   %binary classification
   
%    [scores,predictlabel] = posterior(nb, data(:,1:size(data,2)-1));

   scores = glmval(nb,data(:,1:size(data,2)-1),'logit'); %�������
   
   probs1 = scores';
   probs2 = 1 - probs1;
   probs = [probs2;probs1];
   
else
   %multiclass classification
   expx=exp(w*x); %classnum*t
   probs=expx./repmat(sum(expx),classnum,1);
end

%to avoid log zero
tmp=(probs<1e-15);
entropyvec=- probs.*log2(probs+tmp*1e-15);
entropyvec=sum(entropyvec)'; %t*1

