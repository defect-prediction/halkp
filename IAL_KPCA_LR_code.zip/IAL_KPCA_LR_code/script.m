clc;
clear all;
dbstop if error
startup;

labelset00 = xlsread('C:\Users\XuZhou\Desktop\IAL_KPCA_LR_code\dataset\excel\ant-1.3.xlsx');
labelset0 = labelset00;

testset0 = xlsread('C:\Users\XuZhou\Desktop\IAL_KPCA_LR_code\dataset\excel\ant-1.4.xlsx');

%normalization
labelset = zscore(labelset0(:,1:size(labelset0,2)-1));
labelsetlabel = labelset0(:,size(labelset0,2));
testset = zscore(testset0(:,1:size(testset0,2)-1));
testsetlabel = testset0(:,size(testset0,2));

labelset = [labelset labelsetlabel];
testset = [testset testsetlabel];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%parameter setting: you can adjust them%%%%%%%%%%%%%%%
options.KernelType = 'Gaussian';
options.t = 2; %parameters of kernel
% subsampling.method
%   0: use all
%	1: top most uncertain ones
%	2: clustering
%	3: random selection
% subsampling.num
% subsampling.method = 0;
% subsampling.num = 0; % sample set size of unlabeled data
addnum = ceil(0.2 * size(testset,1)); % selection iterations

%%==========================method=========================
fprintf('Adaptive Active Learning begins...\n');
%beta is the bias parameter between uncertainty and information density
fprintf('allbeta 0.0...\n');
[performance_00_kpca]=ActiveCombSample(labelset,testset,0,options, addnum);
fprintf('allbeta 0.1...\n');
[performance_01_kpca]=ActiveCombSample(labelset,testset,0.1,options, addnum);
fprintf('allbeta 0.2...\n');
[performance_02_kpca]=ActiveCombSample(labelset,testset,0.2,options, addnum);
fprintf('allbeta 0.3...\n');
[performance_03_kpca]=ActiveCombSample(labelset,testset,0.3,options, addnum);
fprintf('allbeta 0.4...\n');
[performance_04_kpca]=ActiveCombSample(labelset,testset,0.4,options, addnum);
fprintf('allbeta 0.5...\n');
[performance_05_kpca]=ActiveCombSample(labelset,testset,0.5,options, addnum);
fprintf('allbeta 0.6...\n');
[performance_06_kpca]=ActiveCombSample(labelset,testset,0.6,options, addnum);
fprintf('allbeta 0.7...\n');
[performance_07_kpca]=ActiveCombSample(labelset,testset,0.7,options, addnum);
fprintf('allbeta 0.8...\n');
[performance_08_kpca]=ActiveCombSample(labelset,testset,0.8,options, addnum);
fprintf('allbeta 0.9...\n');
[performance_09_kpca]=ActiveCombSample(labelset,testset,0.9,options, addnum);
fprintf('allbeta 1.0...\n');
[performance_10_kpca]=ActiveCombSample(labelset,testset,1.0,options, addnum);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  first IAL, then KPCA   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%selecting 5%
performance_kpca_005 = [performance_00_kpca(1,:); performance_01_kpca(1,:); performance_02_kpca(1,:); performance_03_kpca(1,:); performance_04_kpca(1,:); performance_05_kpca(1,:); performance_06_kpca(1,:); performance_07_kpca(1,:); performance_08_kpca(1,:); performance_09_kpca(1,:); performance_10_kpca(1,:)];
kpca_F_measure_005 = [performance_00_kpca(1,1) performance_01_kpca(1,1) performance_02_kpca(1,1) performance_03_kpca(1,1) performance_04_kpca(1,1) performance_05_kpca(1,1) performance_06_kpca(1,1) performance_07_kpca(1,1) performance_08_kpca(1,1) performance_09_kpca(1,1) performance_10_kpca(1,1)];
[~,index_kpca_005] = max(kpca_F_measure_005);
performance_kpca_005_max = [performance_kpca_005(index_kpca_005,:),(index_kpca_005-1)*0.1];

%selecting 10%
performance_kpca_010 = [performance_00_kpca(2,:); performance_01_kpca(2,:); performance_02_kpca(2,:); performance_03_kpca(2,:); performance_04_kpca(2,:); performance_05_kpca(2,:); performance_06_kpca(2,:); performance_07_kpca(2,:); performance_08_kpca(2,:); performance_09_kpca(2,:); performance_10_kpca(2,:)];
kpca_F_measure_010 = [performance_00_kpca(2,1) performance_01_kpca(2,1) performance_02_kpca(2,1) performance_03_kpca(2,1) performance_04_kpca(2,1) performance_05_kpca(2,1) performance_06_kpca(2,1) performance_07_kpca(2,1) performance_08_kpca(2,1) performance_09_kpca(2,1) performance_10_kpca(2,1)];
[~,index_kpca_010] = max(kpca_F_measure_010);
performance_kpca_010_max = [performance_kpca_010(index_kpca_010,:),(index_kpca_010-1)*0.1];

%selecting  15%
performance_kpca_015 = [performance_00_kpca(3,:); performance_01_kpca(3,:); performance_02_kpca(3,:); performance_03_kpca(3,:); performance_04_kpca(3,:); performance_05_kpca(3,:); performance_06_kpca(3,:); performance_07_kpca(3,:); performance_08_kpca(3,:); performance_09_kpca(3,:); performance_10_kpca(3,:)];
kpca_F_measure_015 = [performance_00_kpca(3,1) performance_01_kpca(3,1) performance_02_kpca(3,1) performance_03_kpca(3,1) performance_04_kpca(3,1) performance_05_kpca(3,1) performance_06_kpca(3,1) performance_07_kpca(3,1) performance_08_kpca(3,1) performance_09_kpca(3,1) performance_10_kpca(3,1)];
[~,index_kpca_015] = max(kpca_F_measure_015);
performance_kpca_015_max = [performance_kpca_015(index_kpca_015,:),(index_kpca_015-1)*0.1];

%selecting 20%
performance_kpca_020 = [performance_00_kpca(4,:); performance_01_kpca(4,:); performance_02_kpca(4,:); performance_03_kpca(4,:); performance_04_kpca(4,:); performance_05_kpca(4,:); performance_06_kpca(4,:); performance_07_kpca(4,:); performance_08_kpca(4,:); performance_09_kpca(4,:); performance_10_kpca(4,:)];
kpca_F_measure_020 = [performance_00_kpca(4,1) performance_01_kpca(4,1) performance_02_kpca(4,1) performance_03_kpca(4,1) performance_04_kpca(4,1) performance_05_kpca(4,1) performance_06_kpca(4,1) performance_07_kpca(4,1) performance_08_kpca(4,1) performance_09_kpca(4,1) performance_10_kpca(4,1)];
[~,index_kpca_020] = max(kpca_F_measure_020);
performance_kpca_020_max = [performance_kpca_020(index_kpca_020,:),(index_kpca_020-1)*0.1];


% measure = [performance_ori; performance_ori_pca; performance_ori_kpca; performance_non_005_max;performance_pca_005_max;performance_kpca_005_max;performance_non_010_max;performance_pca_010_max;performance_kpca_010_max;performance_non_015_max;performance_pca_015_max;performance_kpca_015_max;performance_non_020_max;performance_pca_020_max;performance_kpca_020_max;];
measure = [
         performance_kpca_005_max, performance_kpca_010_max, performance_kpca_015_max, performance_kpca_020_max];
xlswrite('result-ALKPCA.xlsx',measure) 